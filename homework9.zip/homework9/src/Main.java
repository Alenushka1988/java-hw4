import java.util.Scanner;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите первое слово:");
        String word1 = scr.next();
        System.out.println("Введите второе слово: ");
        String word2 = scr.next();
        if ((word1.length() & 1) == 0 && (word2.length() & 1) == 0){
            String newWord = word1.substring(0, word1.length() / 2) + word2.substring(word2.length() / 2);
            System.out.println("Результат " + newWord);
        } else {

            System.out.println("Одно из введенных слов не состоит из четного колличества букв.");
        }
    }



}