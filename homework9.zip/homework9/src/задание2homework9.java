import java.util.Scanner;

public class задание2homework9 {

    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println("Введите первое число: ");
        int num1 = scr.nextInt();
        System.out.println("Введите второе число: ");
        int num2 = scr.nextInt();
        printResult("Сложение", num1 + num2);
        printResult("Вычитание", num1 - num2);
        printResult("Умножение", num1 * num2);
        printResult("Деление", num2 != 0 ? num1 / num2 : 0);
    }

    public static void printResult(String operation,int result) {
        System.out.println(operation + ": " + result);
    }
}
